cd $HOME &&
sudo add-apt-repository ppa:danielrichter2007/grub-customizer &&
sudo apt-get -y update &&
sudo apt-get -y install grub-customizer &&
sudo apt-get -y install gksu
#gksu grub-customizer
