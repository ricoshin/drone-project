#vim, dconf-editor
. ./etc.sh &&

#edimax(bluetooth)
. ./edi.sh &&

#grub-customizer(boot sequence)
cd $HOME &&
. ./grub.sh &&

#~/.bashrc, ~/.vimrc
. ./bash.sh &&
. ./vimrc.sh &&

#ROS(indigo)
. ./ros_install.sh catkin_ws indigo &&

#simulator-erle
. ./se.sh &&

#simulator-tum
. ./st.sh
