echo "
alias vb='vi $HOME/.bashrc'
alias sb='source $HOME/.bashrc'
alias i0='sudo init 0'
alias i6='sudo init 6'
alias cw='cd $HOME/catkin_ws/'
alias cs='cd $HOME/catkin_ws/src'

alias se1='source $HOME/catkin_ws/sim_erle/devel/setup.bash &&
cd $HOME/catkin_ws/sim_erle/ardupilot/ArduCopter &&
../Tools/autotest/sim_vehicle.sh -j 4 -f Gazebo --map --console'
#param load $HOME/catkin_ws/sim_erle/ardupilot/Tools/Frame_params/Erle-Copter.param
alias se2='source $HOME/catkin_ws/sim_erle/devel/setup.bash &&
roslaunch ardupilot_sitl_gazebo_plugin erlecopter_spawn.launch'

alias st1='source $HOME/catkin_ws/sim_ar/devel/setup.bash &&
roslaunch cvg_sim_gazebo ardrone_testworld.launch'
alias st2='source $HOME/catkin_ws/sim_ar/devel/setup.bash &&
roslaunch tum_ardrone tum_ardrone.launch'
" >> $HOME/.bashrc
