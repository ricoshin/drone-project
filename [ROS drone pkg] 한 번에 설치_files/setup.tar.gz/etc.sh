sudo apt-get -y install vim\
		 dconf-editor
