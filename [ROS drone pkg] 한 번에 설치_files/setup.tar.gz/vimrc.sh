echo "
\"cindent사용 시 블럭을 들여 쓸 크기 설정
set sw=4
\"line 표시
set number
\"auto index
set autoindent
\"smart index
set smartindent
\"c style index
set cindent
\"탭을 4칸으로
set tabstop=4
\"검색 시 대소문자 구별하지 않음
set ignorecase
\"검색 시 강조
set hlsearch
\"tab 대신 띄어쓰기
\"set expandtab
\"사용하는 색상에 맞춰 문법 하이라이트 색상이 달라짐
set background=dark
\"방향키로 이동 가능
\"set nocompatible
\"source $VIMRUNTIME/mswin.vim
\"behave mswin
\"bs 사용 가능
\"set bs=indent,eol,start
\"명령어 히스토리 1000개로
set history=1000
\"상태표시줄에 커서 위치 표시
set ruler
\"제목을 표시
set title
\"매칭되는 괄호 표시
set showmatch
\"자동 줄바꿈 하지 않음
\"set nowrap
\"문법 하이라이트 켜기
syntax on
" >> $HOME/.vimrc
