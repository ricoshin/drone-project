mkdir -p $HOME/catkin_ws/sim_ar/src &&
cd $HOME/catkin_ws/sim_ar/src &&
catkin_init_workspace &&

git clone https://github.com/AutonomyLab/ardrone_autonomy.git &&
git clone https://github.com/occomco/tum_simulator.git &&
git clone https://github.com/tum-vision/tum_ardrone.git -b indigo-devel &&

cd .. &&
rosdep install --from-paths src --ignore-src --rosdistro indigo -y &&
catkin_make &&
source devel/setup.bash
