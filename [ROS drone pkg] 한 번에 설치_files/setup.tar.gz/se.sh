#----------Configuring your Ubuntu machine----------
#install the base packages
sudo apt-get -y update &&
sudo apt-get -y install gawk \
		 make \
		 git \
		 curl \
		 cmake &&
#install the dependencies for MAVProxy
sudo apt-get -y install g++ \
		 python-pip \
		 python-matplotlib \
		 python-serial \
		 python-wxgtk2.8 \
		 python-scipy \
		 python-opencv \
		 python-numpy \
		 python-pyparsing \
		 ccache \
		 realpath \
		 libopencv-dev &&

#install MAVProxy
sudo pip2 install pymavlink \
		 MAVProxy \
		 catkin_pkg --upgrade &&
#Download and install ArUco
cd $HOME &&
wget http://downloads.sourceforge.net/project/aruco/1.3.0/aruco-1.3.0.tgz &&
tar -xvzf aruco-1.3.0.tgz &&
cd aruco-1.3.0/ &&
mkdir build && cd build &&
cmake .. &&
make &&
sudo make install &&
sudo rm -rf $HOME/aruco* &&

#----------APM/Ardupilot----------
#Compile a specific branch of ardupilot
mkdir -p $HOME/catkin_ws/sim_erle/src &&
cd $HOME/catkin_ws/sim_erle/src &&
catkin_init_workspace &&
cd .. &&
git clone https://github.com/erlerobot/ardupilot &&
cd ardupilot &&
git checkout gazebo &&
#Getting latest version of JSBSim
cd $HOME/catkin_ws/sim_erle &&
git clone git://github.com/tridge/jsbsim.git &&
sudo apt-get -y install libtool \
		     automake \
		     autoconf \
		     libexpat1-dev &&
cd jsbsim &&
./autogen.sh --enable-libraries &&
make -j4 &&
sudo make install &&
#Get rosinstall and some additional dependencies
sudo apt-get -y install python-rosinstall \
		 ros-indigo-octomap-msgs\
		 ros-indigo-joy \
		 ros-indigo-geodesy \
		 ros-indigo-octomap-ros \
		 ros-indigo-mavlink \
		 ros-indigo-control-toolbox \
		 unzip &&
#Add OSRF repository and install drcsim
sudo sh -c 'echo "deb http://packages.osrfoundation.org/drc/ubuntu $(lsb_release -sc) main" > /etc/apt/sources.list.d/drc-latest.list' &&
wget http://packages.osrfoundation.org/drc.key -O - | sudo apt-key add - &&
sudo apt-get -y update &&
sudo apt-get -y install drcsim &&

#----------Initialize the workspace----------
cd $HOME/catkin_ws/sim_erle/ &&
catkin_make &&
source devel/setup.bash &&
#Download these repositories in src:
cd src/
git clone https://github.com/erlerobot/ardupilot_sitl_gazebo_plugin &&
git clone https://github.com/tu-darmstadt-ros-pkg/hector_gazebo/ &&
git clone https://github.com/erlerobot/rotors_simulator -b sonar_plugin &&
git clone https://github.com/PX4/mav_comm.git &&
git clone https://github.com/ethz-asl/glog_catkin.git &&
git clone https://github.com/catkin/catkin_simple.git &&
git clone https://github.com/erlerobot/mavros.git &&
#Then compile everything together:
cd .. &&
catkin_make --pkg mav_msgs &&
source devel/setup.bash &&
catkin_make &&

#----------Install Gazebo4----------
#Setup your computer to accept software from packages.osrfoundation.org
sudo sh -c 'echo "deb http://packages.osrfoundation.org/gazebo/ubuntu `lsb_release -cs` main" > /etc/apt/sources.list.d/gazebo-latest.list' &&
#Setup keys
wget http://packages.osrfoundation.org/gazebo.key -O - | sudo apt-key add - &&
#Install gazebo4
sudo apt-get -y update &&
sudo apt-get -y install gazebo4 &&
#For developers that works on top of Gazebo, one extra package
sudo apt-get -y install libgazebo4-dev &&

#----------Install Gazebo models----------
mkdir -p $HOME/.gazebo/models &&
cd $HOME &&
git clone https://github.com/erlerobot/erle_gazebo_models &&
mv erle_gazebo_models/* $HOME/.gazebo/models &&
sudo rm -rf erle_gazebo_models
