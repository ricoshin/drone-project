sudo apt-get -y update &&
sudo apt-get -y install linux-headers-generic build-essential git &&
cd $HOME &&
git clone https://github.com/gnab/rtl8812au.git &&
cd $HOME/rtl8812au &&
make &&
sudo make install &&
sudo rm -rf $HOME/rtl8812au
#sudo modprobe 8812au
